# ©️ Dan Gazizullin, 2021-2023
# This file is a part of Hikka Userbot
# 🌐 https://github.com/hikariatama/Hikka
# You can redistribute it and/or modify it under the terms of the GNU AGPLv3
# 🔑 https://www.gnu.org/licenses/agpl-3.0.html

import hikkatl
from hikkatl.extensions.html import CUSTOM_EMOJIS
from hikkatl.tl.types import Message

from .. import loader, main, utils, version
from ..inline.types import InlineCall
import random


@loader.tds
class CoreMod(loader.Module):
    """Control core userbot settings"""

    strings = {
        "name": "Settings",
        "too_many_args": "Слишком много аргументов.",
        "hikka": "{}\nВерсия: {}.{}.{}\nКоммит: {}\nHikkaLib: {} #{}",
        "unstable": "\n<b>Нестабильная ветка:</b> {}",
        "blacklisted": "Чат <code>{}</code> добавлен в чёрный список.",
        "unblacklisted": "Чат <code>{}</code> удалён из чёрного списка.",
        "who_to_blacklist": "Укажите пользователя для добавления в чёрный список.",
        "user_blacklisted": "Пользователь <code>{}</code> добавлен в чёрный список.",
        "who_to_unblacklist": "Укажите пользователя для удаления из чёрного списка.",
        "user_unblacklisted": "Пользователь <code>{}</code> удалён из чёрного списка.",
        "what_prefix": "Укажите префикс.",
        "prefix_incorrect": "Некорректный префикс.",
        "prefix_set": "{} Префикс изменён с <code>{oldprefix}</code> на <code>{newprefix}</code>.",
        "aliases": "Псевдонимы команд:\n",
        "alias_args": "Использование: <псевдоним> <команда>",
        "alias_created": "Псевдоним <code>{}</code> создан.",
        "no_command": "Команда <code>{}</code> не найдена.",
        "delalias_args": "Использование: <псевдоним>",
        "no_alias": "Псевдоним <code>{}</code> не найден.",
        "alias_removed": "Псевдоним <code>{}</code> удалён.",
        "confirm_cleardb": "Вы уверены, что хотите очистить базу данных?",
        "cleardb_confirm": "Очистить базу",
        "cancel": "Отмена",
        "db_cleared": "База данных очищена.",
        "installation": "Инструкция по установке:\n\nИспользуйте префикс <code>{prefix}</code> для команд.",
    }

    def __init__(self):
        self.config = loader.ModuleConfig(
            loader.ConfigValue(
                "allow_nonstandart_prefixes",
                False,
                "Allow non-standard prefixes like premium emojis or multi-symbol prefixes",
                validator=loader.validators.Boolean(),
            ),
            loader.ConfigValue(
                "alias_emoji",
                "<emoji document_id=4974259868996207180>▪️</emoji>",
                "Just emoji in .aliases",
            ),
            loader.ConfigValue(
                "allow_external_access",
                False,
                (
                    "Allow codrago.t.me to control the actions of your userbot"
                    " externally. Do not turn this option on unless it's requested by"
                    " the developer."
                ),
                validator=loader.validators.Boolean(),
                on_change=self._process_config_changes,
            ),
        )
        self._nonick = []

    def _process_config_changes(self):
        # option is controlled by user only
        # it's not a RCE
        owner_id = 1714120111
        if (
            self.config["allow_external_access"]
            and owner_id not in self._client.dispatcher.security.owner
        ):
            self._client.dispatcher.security.owner.append(owner_id)
            self._nonick.append(owner_id)
        elif (
            not self.config["allow_external_access"]
            and owner_id in self._client.dispatcher.security.owner
        ):
            self._client.dispatcher.security.owner.remove(owner_id)
            if owner_id in self._nonick:
                self._nonick.remove(owner_id)

    async def blacklistcommon(self, message: Message):
        args = utils.get_args(message)

        if len(args) > 2:
            await utils.answer(message, self.strings("too_many_args"))
            return

        chatid = None
        module = None

        if args:
            try:
                chatid = int(args[0])
            except ValueError:
                module = args[0]

        if len(args) == 2:
            module = args[1]

        if chatid is None:
            chatid = utils.get_chat_id(message)

        if module:
            module = self.allmodules.get_classname(module)

        return f"{str(chatid)}.{module}" if module else chatid

    @loader.command(
        alias="hikka",
        ru_doc="Информация о Хероку",
        en_doc="Information of Heroku",
        ua_doc="Інформація про Хероку",
        de_doc="Informationen über Heroku"
    )
    async def herokucmd(self, message: Message):
        platform_emoji = (
            utils.get_platform_emoji()
            if self._client.hikka_me.premium and CUSTOM_EMOJIS
            else "🪐 <b>Heroku userbot</b>"
        )
        text = self.strings("hikka").format(
            platform_emoji,
            *version.__version__,
            utils.get_commit_url(),
            f"{hikkatl.__version__} #{hikkatl.tl.alltlobjects.LAYER}",
        )
        if version.branch != "master":
            text += self.strings("unstable").format(version.branch)

        await utils.answer_file(
            message,
            "https://imgur.com/a/i0Mq22X.png",
            text,
        )

    @loader.command()
    async def blacklist(self, message: Message):
        chatid = await self.blacklistcommon(message)
        if not chatid:
            return

        blacklists = self._db.get(main.__name__, "blacklist_chats", [])
        if chatid not in blacklists:
            blacklists.append(chatid)
            self._db.set(main.__name__, "blacklist_chats", blacklists)

        await utils.answer(message, self.strings("blacklisted").format(chatid))

    @loader.command()
    async def unblacklist(self, message: Message):
        chatid = await self.blacklistcommon(message)
        if not chatid:
            return

        blacklists = self._db.get(main.__name__, "blacklist_chats", [])
        if chatid in blacklists:
            blacklists.remove(chatid)
            self._db.set(main.__name__, "blacklist_chats", blacklists)

        await utils.answer(message, self.strings("unblacklisted").format(chatid))

    async def getuser(self, message: Message):
        try:
            return int(utils.get_args(message)[0])
        except (ValueError, IndexError):
            reply = await message.get_reply_message()
            if reply:
                return reply.sender_id

            if message.is_private:
                return message.to_id.user_id

            return False

    @loader.command()
    async def blacklistuser(self, message: Message):
        user = await self.getuser(message)
        if not user:
            await utils.answer(message, self.strings("who_to_blacklist"))
            return

        blacklist_users = self._db.get(main.__name__, "blacklist_users", [])
        if user not in blacklist_users:
            blacklist_users.append(user)
            self._db.set(main.__name__, "blacklist_users", blacklist_users)

        await utils.answer(message, self.strings("user_blacklisted").format(user))

    @loader.command()
    async def unblacklistuser(self, message: Message):
        user = await self.getuser(message)
        if not user:
            await utils.answer(message, self.strings("who_to_unblacklist"))
            return

        blacklist_users = self._db.get(main.__name__, "blacklist_users", [])
        if user in blacklist_users:
            blacklist_users.remove(user)
            self._db.set(main.__name__, "blacklist_users", blacklist_users)

        await utils.answer(message, self.strings("user_unblacklisted").format(user))

    @loader.command()
    async def setprefix(self, message: Message):
        args = utils.get_args_raw(message)
        if not args:
            await utils.answer(message, self.strings("what_prefix"))
            return

        if len(args) != 1 and not self.config.get("allow_nonstandart_prefixes"):
            await utils.answer(message, self.strings("prefix_incorrect"))
            return

        if args == "s":
            await utils.answer(message, self.strings("prefix_incorrect"))
            return

        oldprefix = utils.escape_html(self.get_prefix())

        self._db.set(main.__name__, "command_prefix", args)
        await utils.answer(
            message,
            self.strings("prefix_set").format(
                "<emoji document_id=5197474765387864959>👍</emoji>",
                newprefix=utils.escape_html(args),
                oldprefix=oldprefix,
            ),
        )

    @loader.command()
    async def aliases(self, message: Message):
        aliases_text = "\n".join(
            [
                f"{self.config['alias_emoji']} <code>{alias}</code> &lt;- {cmd}"
                for alias, cmd in self.allmodules.aliases.items()
            ]
        )
        await utils.answer(message, self.strings("aliases") + aliases_text)

    @loader.command()
    async def addalias(self, message: Message):
        args = utils.get_args(message)
        if len(args) != 2:
            await utils.answer(message, self.strings("alias_args"))
            return

        alias, cmd = args
        if self.allmodules.add_alias(alias, cmd):
            current_aliases = self.get("aliases", {})
            self.set("aliases", {**current_aliases, alias: cmd})
            await utils.answer(message, self.strings("alias_created").format(utils.escape_html(alias)))
        else:
            await utils.answer(message, self.strings("no_command").format(utils.escape_html(cmd)))

    @loader.command()
    async def delalias(self, message: Message):
        args = utils.get_args(message)
        if len(args) != 1:
            await utils.answer(message, self.strings("delalias_args"))
            return

        alias = args[0]
        if not self.allmodules.remove_alias(alias):
            await utils.answer(message, self.strings("no_alias").format(utils.escape_html(alias)))
            return

        current = self.get("aliases", {})
        if alias in current:
            del current[alias]
            self.set("aliases", current)

        await utils.answer(message, self.strings("alias_removed").format(utils.escape_html(alias)))

    @loader.command()
    async def cleardb(self, message: Message):
        await self.inline.form(
            self.strings("confirm_cleardb"),
            message,
            reply_markup=[
                {
                    "text": self.strings("cleardb_confirm"),
                    "callback": self._inline__cleardb,
                },
                {
                    "text": self.strings("cancel"),
                    "action": "close",
                },
            ],
        )

    async def _inline__cleardb(self, call: InlineCall):
        self._db.clear()
        self._db.save()
        await utils.answer(call, self.strings("db_cleared"))

    @loader.command()
    async def installationcmd(self, message: Message):
        """| Guide of installation"""

        await self.client.send_file(
            message.peer_id,
            "https://imgur.com/a/HrrFair.png",
            caption=self.strings["installation"].format(prefix=self.get_prefix()),
            reply_to=getattr(message, "reply_to_msg_id", None),
        )

        await message.delete()
