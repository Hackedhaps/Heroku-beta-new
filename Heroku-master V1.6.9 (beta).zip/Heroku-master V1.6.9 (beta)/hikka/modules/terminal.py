#    Friendly Telegram (telegram userbot)
#    Copyright (C) 2018-2019 The Authors

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.

#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.

# ©️ Dan Gazizullin, 2021-2023
# This file is a part of Hikka Userbot
# 🌐 https://github.com/hikariatama/Hikka
# You can redistribute it and/or modify it under the terms of the GNU AGPLv3
# 🔑 https://www.gnu.org/licenses/agpl-3.0.html

# meta developer: @bsolute

import asyncio
import contextlib
import logging
import os
import re
import typing

import hikkatl

from .. import loader, utils

logger = logging.getLogger(__name__)


def hash_msg(message):
    return f"{str(utils.get_chat_id(message))}/{str(message.id)}"


async def read_stream(func: callable, stream, delay: float):
    last_task = None
    data = b""
    while True:
        dat = await stream.read(1)
        if not dat:
            # Конец потока (EOF)
            if last_task:
                last_task.cancel()
                await func(data.decode())
            break
        data += dat
        if last_task:
            last_task.cancel()
        last_task = asyncio.ensure_future(sleep_for_task(func, data, delay))


async def sleep_for_task(func: callable, data: bytes, delay: float):
    await asyncio.sleep(delay)
    await func(data.decode())


class MessageEditor:
    def __init__(
        self,
        message: hikkatl.tl.types.Message,
        command: str,
        config,
        strings,
        request_message,
    ):
        self.message = message
        self.command = command
        self.stdout = ""
        self.stderr = ""
        self.rc = None
        self.redraws = 0
        self.config = config
        self.strings = strings
        self.request_message = request_message

    async def update_stdout(self, stdout):
        self.stdout = stdout
        await self.redraw()

    async def update_stderr(self, stderr):
        self.stderr = stderr
        await self.redraw()

    async def redraw(self):
        text = self.strings("running").format(utils.escape_html(self.command))  # fmt: skip

        if self.rc is not None:
            text += self.strings("finished").format(utils.escape_html(str(self.rc)))

        text += self.strings("stdout")
        text += utils.escape_html(self.stdout[max(len(self.stdout) - 2048, 0) :])
        stderr = utils.escape_html(self.stderr[max(len(self.stderr) - 1024, 0) :])
        if stderr:
            text += self.strings("stderr") + stderr
        text += self.strings("end")

        with contextlib.suppress(hikkatl.errors.rpcerrorlist.MessageNotModifiedError):
            try:
                self.message = await utils.answer(self.message, text)
            except hikkatl.errors.rpcerrorlist.MessageTooLongError as e:
                logger.error(e)
                logger.error(text)

    async def cmd_ended(self, rc):
        self.rc = rc
        self.state = 4
        await self.redraw()

    def update_process(self, process):
        pass


class SudoMessageEditor(MessageEditor):
    # Предполагается, что эти сообщения безопасно парсить
    PASS_REQ = "[sudo] password for"
    WRONG_PASS = r"\[sudo\] password for (.*): Sorry, try again\."
    TOO_MANY_TRIES = r"\[sudo\] password for (.*): sudo: [0-9]+ incorrect password attempts"

    def __init__(self, message, command, config, strings, request_message):
        super().__init__(message, command, config, strings, request_message)
        self.process = None
        self.state = 0
        self.authmsg = None
        self._tg_id = message.from_id or 0  # id пользователя (если нужно)

    def update_process(self, process):
        logger.debug("Получен объект процесса: %s", process)
        self.process = process

    async def update_stderr(self, stderr):
        logger.debug("Обновление stderr: %s", stderr)
        self.stderr = stderr
        lines = stderr.strip().split("\n")
        lastline = lines[-1]
        lastlines = lastline.rsplit(" ", 1)
        handled = False

        if (
            len(lines) > 1
            and re.fullmatch(self.WRONG_PASS, lines[-2])
            and lastlines[0] == self.PASS_REQ
            and self.state == 1
        ):
            logger.debug("Смена состояния на 0 – неверный пароль")
            await self.authmsg.edit(self.strings("auth_failed"))
            self.state = 0
            handled = True
            await asyncio.sleep(2)
            await self.authmsg.delete()

        if lastlines[0] == self.PASS_REQ and self.state == 0:
            logger.debug("Обнаружен запрос sudo пароля")
            text = self.strings("auth_needed").format(self._tg_id)
            try:
                await utils.answer(self.message, text)
            except hikkatl.errors.rpcerrorlist.MessageNotModifiedError as e:
                logger.debug(e)

            logger.debug("Отредактировано сообщение с ссылкой на пользователя")
            command_html = "<code>" + utils.escape_html(self.command) + "</code>"
            user = utils.escape_html(lastlines[1][:-1])

            self.authmsg = await self.message[0].client.send_message(
                "me",
                self.strings("auth_msg").format(command_html, user),
            )
            logger.debug("Отправлено сообщение самому себе")

            self.message[0].client.remove_event_handler(self.on_message_edited)
            self.message[0].client.add_event_handler(
                self.on_message_edited,
                hikkatl.events.messageedited.MessageEdited(chats=["me"]),
            )

            logger.debug("Зарегистрирован обработчик событий редактирования сообщений")
            handled = True

        if len(lines) > 1 and (
            re.fullmatch(self.TOO_MANY_TRIES, lastline) and self.state in {1, 3, 4}
        ):
            logger.debug("Слишком много неправильных попыток ввода пароля")
            await utils.answer(self.message, self.strings("auth_locked"))
            if self.authmsg:
                await self.authmsg.delete()
            self.state = 2
            handled = True

        if not handled:
            logger.debug("Не найден sudo лог. Обновление экрана.")
            if self.authmsg is not None:
                await self.authmsg.delete()
                self.authmsg = None
            self.state = 2
            await self.redraw()

        logger.debug("Текущее состояние: %s", self.state)

    async def update_stdout(self, stdout):
        self.stdout = stdout

        if self.state != 2:
            self.state = 3  # Получены данные stdout

        if self.authmsg is not None:
            await self.authmsg.delete()
            self.authmsg = None

        await self.redraw()

    async def on_message_edited(self, message):
        # Сообщение содержит чувствительную информацию.
        if self.authmsg is None:
            return

        logger.debug("Обновление сообщения: %s", str(message.id))

        if hash_msg(message) == hash_msg(self.authmsg):
            # Пользователь ввёл пароль для sudo, отправляем его в stdin процесса
            try:
                self.authmsg = await utils.answer(message, self.strings("auth_ongoing"))
            except hikkatl.errors.rpcerrorlist.MessageNotModifiedError:
                # Если не удалось отредактировать, удаляем сообщение с паролем
                await message.delete()

            self.state = 1
            self.process.stdin.write(
                message.message.message.split("\n", 1)[0].encode() + b"\n"
            )


class RawMessageEditor(SudoMessageEditor):
    def __init__(
        self,
        message,
        command,
        config,
        strings,
        request_message,
        show_done=False,
    ):
        super().__init__(message, command, config, strings, request_message)
        self.show_done = show_done

    async def redraw(self):
        logger.debug("RC: %s", self.rc)

        if self.rc is None:
            text = (
                "<code>"
                + utils.escape_html(self.stdout[max(len(self.stdout) - 4095, 0) :])
                + "</code>"
            )
        elif self.rc == 0:
            text = (
                "<code>"
                + utils.escape_html(self.stdout[max(len(self.stdout) - 4090, 0) :])
                + "</code>"
            )
        else:
            text = (
                "<code>"
                + utils.escape_html(self.stderr[max(len(self.stderr) - 4095, 0) :])
                + "</code>"
            )

        if self.rc is not None and self.show_done:
            text += "\n" + self.strings("done")

        logger.debug("Редактируем сообщение с текстом:\n%s", text)

        with contextlib.suppress(
            hikkatl.errors.rpcerrorlist.MessageNotModifiedError,
            hikkatl.errors.rpcerrorlist.MessageEmptyError,
            ValueError,
        ):
            try:
                await utils.answer(self.message, text)
            except hikkatl.errors.rpcerrorlist.MessageTooLongError as e:
                logger.error(e)
                logger.error(text)


@loader.tds
class TerminalMod(loader.Module):
    """Запуск терминальных команд"""

    strings = {
        "name": "Terminal",
        "running": "<b>Выполнение:</b> {}\n\n",
        "finished": "\n\n<b>Завершено с кодом:</b> {}\n\n",
        "stdout": "<b>STDOUT:</b>\n",
        "stderr": "\n<b>STDERR:</b>\n",
        "end": "\n\n",
        "auth_needed": "<b>Требуется пароль sudo для пользователя {}</b>",
        "auth_msg": "Введите пароль для команды:\n{}\n\nПользователь: {}",
        "auth_failed": "<b>Аутентификация не удалась. Попробуйте снова.</b>",
        "auth_locked": "<b>Слишком много неправильных попыток. Аутентификация заблокирована.</b>",
        "done": "<b>Готово.</b>",
        "what_to_kill": "Ответьте на сообщение с командой, которую хотите завершить.",
        "kill_fail": "Не удалось завершить процесс.",
        "killed": "Процесс успешно завершён.",
        "no_cmd": "Команда для завершения не найдена или уже завершена.",
        "fw_protect": "Задержка защиты от флуд-атаки при обновлении вывода (в секундах).",
    }

    def __init__(self):
        self.config = loader.ModuleConfig(
            loader.ConfigValue(
                "FLOOD_WAIT_PROTECT",
                2,
                lambda: self.strings("fw_protect"),
                validator=loader.validators.Integer(minimum=0),
            ),
        )
        self.activecmds = {}

    @loader.command()
    async def terminalcmd(self, message):
        """Запуск произвольной команды в терминале"""
        args = utils.get_args_raw(message)
        if not args:
            await utils.answer(message, "Введите команду для выполнения.")
            return
        await self.run_command(message, args)

    @loader.command()
    async def aptcmd(self, message):
        """Установка пакетов через apt (с sudo если не root)"""
        args = utils.get_args_raw(message)
        if not args:
            await utils.answer(message, "Введите параметры для apt.")
            return

        prefix = "apt " if os.geteuid() == 0 else "sudo -S apt "
        cmd = f"{prefix}{args} -y"
        editor = RawMessageEditor(
            message,
            f"apt {args}",
            self.config,
            self.strings,
            message,
            show_done=True,
        )
        await self.run_command(message, cmd, editor)

    async def run_command(
        self,
        message: hikkatl.tl.types.Message,
        cmd: str,
        editor: typing.Optional[MessageEditor] = None,
    ):
        # Проверяем, есть ли sudo без -S, и добавляем -S если нужно
        if cmd.startswith("sudo") and "-S" not in cmd.split(" ", 1)[1]:
            parts = cmd.split(" ", 1)
            cmd = f"{parts[0]} -S {parts[1]}"

        sproc = await asyncio.create_subprocess_shell(
            cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=utils.get_base_dir(),
        )

        if editor is None:
            editor = SudoMessageEditor(message, cmd, self.config, self.strings, message)

        editor.update_process(sproc)

        self.activecmds[hash_msg(message)] = sproc

        await editor.redraw()

        await asyncio.gather(
            read_stream(
                editor.update_stdout,
                sproc.stdout,
                self.config["FLOOD_WAIT_PROTECT"],
            ),
            read_stream(
                editor.update_stderr,
                sproc.stderr,
                self.config["FLOOD_WAIT_PROTECT"],
            ),
        )

        await editor.cmd_ended(await sproc.wait())
        del self.activecmds[hash_msg(message)]

    @loader.command()
    async def terminatecmd(self, message):
        """Завершить процесс, запущенный командой (ответ на сообщение с командой)"""
        if not message.is_reply:
            await utils.answer(message, self.strings("what_to_kill"))
            return

        reply_msg = await message.get_reply_message()
        key = hash_msg(reply_msg)
        if key in self.activecmds:
            try:
                if "-f" not in utils.get_args_raw(message):
                    self.activecmds[key].terminate()
                else:
                    self.activecmds[key].kill()
            except Exception:
                logger.exception("Ошибка при завершении процесса")
                await utils.answer(message, self.strings("kill_fail"))
            else:
                await utils.answer(message, self.strings("killed"))
        else:
            await utils.answer(message, self.strings("no_cmd"))
